package com.example.juegoproyecto

data class TareaDTO(
    val id: Int,
    val titulo: String,
    val descripcion: String,
    val fecha: String,
    val completed: Boolean
)
