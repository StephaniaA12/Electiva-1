package com.example.rdekids

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton

class ConfiguracionActivity : AppCompatActivity() {

    private lateinit var switchSonido: Switch
    private lateinit var btnGuardar: AppCompatButton
    private lateinit var btnCerrarSesion: AppCompatButton
    private lateinit var tvUsuario: TextView
    private lateinit var imgPerfil: ImageView
    private lateinit var btnVerTareas: AppCompatButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_configuracion)

        switchSonido = findViewById(R.id.Sonido)
        btnGuardar = findViewById(R.id.GuardarConfig)
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion)
        tvUsuario = findViewById(R.id.tvUsuario)
        imgPerfil = findViewById(R.id.imgPerfil)
        btnVerTareas = findViewById(R.id.btnVerTareas)

        // Verificar sesión activa
        val prefsSesion = getSharedPreferences("SesionUsuario", Context.MODE_PRIVATE)
        val usuario = prefsSesion.getString("usuarioActual", null)

        if (usuario == null) {
            Toast.makeText(this, "Debes iniciar sesión primero", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        // Mostrar nombre del usuario actual
        tvUsuario.text = "Usuario: $usuario"

        // Cargar el valor guardado del sonido
        switchSonido.isChecked = obtenerSonido()

        // Guardar configuración
        btnGuardar.setOnClickListener {
            val sonidoActivo = switchSonido.isChecked
            guardarSonido(sonidoActivo)
            Toast.makeText(this, "Configuración guardada correctamente", Toast.LENGTH_SHORT).show()
        }

        // Ver Tareas
        btnVerTareas.setOnClickListener {
            val intent = Intent(this, TareasActivity::class.java)
            startActivity(intent)
        }

        // Cerrar sesión
        btnCerrarSesion.setOnClickListener {
            cerrarSesion()
            Toast.makeText(this, "Sesión cerrada correctamente", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }

    // Cerrar sesión correctamente
    private fun cerrarSesion() {
        val prefs = getSharedPreferences("SesionUsuario", Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean("logueado", false)
            .remove("usuarioActual")
            .apply()
    }

    // Guardar estado del sonido
    private fun guardarSonido(activo: Boolean) {
        val prefs = getSharedPreferences("ConfiguracionJuego", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("sonido", activo).apply()
    }

    // Obtener estado del sonido
    private fun obtenerSonido(): Boolean {
        val prefs = getSharedPreferences("ConfiguracionJuego", Context.MODE_PRIVATE)
        return prefs.getBoolean("sonido", true)
    }
}








