package com.example.rdekids

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.work.*
import com.example.rdekids.data.GoogleSheetsService
import com.example.rdekids.data.OfflineQueueManager
import com.example.rdekids.utils.NetworkUtils
import com.example.rdekids.data.room.entities.Usuario
import com.example.rdekids.data.repository.SyncRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RegistroActivity : AppCompatActivity() {

    private lateinit var etNombre: EditText
    private lateinit var etCorreo: EditText
    private lateinit var etContrasena: EditText
    private lateinit var btnRegistrar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)

        etNombre = findViewById(R.id.etNombre)
        etCorreo = findViewById(R.id.etCorreo)
        etContrasena = findViewById(R.id.etContrasena)
        btnRegistrar = findViewById(R.id.btnRegistrar)

        btnRegistrar.setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val correo = etCorreo.text.toString().trim()
            val contrasena = etContrasena.text.toString().trim()

            if (nombre.isEmpty() || correo.isEmpty() || contrasena.isEmpty()) {
                Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            verificarYRegistrarUsuario(nombre, correo, contrasena)
        }
    }

    private fun verificarYRegistrarUsuario(nombre: String, correo: String, contrasena: String) {

        // ✅ 1. NO HAY INTERNET → Guardar en Room y en la cola offline
        if (!NetworkUtils.hayInternet(this)) {
            guardarUsuarioOffline(nombre, correo, contrasena)
            Toast.makeText(
                this,
                "Sin internet. Registro guardado y se enviará automáticamente.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        // ✅ 2. SI HAY INTERNET → Consultar lista en Sheets
        Toast.makeText(this, "Verificando usuario...", Toast.LENGTH_SHORT).show()

        GoogleSheetsService.obtenerUsuarios { usuariosArray ->
            runOnUiThread {

                if (usuariosArray == null) {
                    guardarUsuarioOffline(nombre, correo, contrasena)
                    Toast.makeText(
                        this,
                        "No hay conexión. Guardado offline.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@runOnUiThread
                }

                var existe = false
                for (i in 0 until usuariosArray.length()) {
                    val user = usuariosArray.getJSONObject(i)
                    if (
                        nombre.equals(user.optString("nombre", ""), true) ||
                        correo.equals(user.optString("correo", ""), true)
                    ) {
                        existe = true
                        break
                    }
                }

                if (existe) {
                    Toast.makeText(this, "El usuario o correo ya están registrados.", Toast.LENGTH_LONG).show()
                } else {
                    registrarUsuarioOnline(nombre, correo, contrasena)
                }
            }
        }
    }

    private fun registrarUsuarioOnline(nombre: String, correo: String, contrasena: String) {

        Toast.makeText(this, "Registrando usuario...", Toast.LENGTH_SHORT).show()

        GoogleSheetsService.registrarUsuario(nombre, correo, contrasena) { exito, mensaje ->
            runOnUiThread {

                Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show()

                if (exito) {
                    val intent = Intent(this, LoginActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                }
            }
        }
    }

    // ✅ GUARDAR USUARIO OFFLINE EN ROOM Y ENVIARLO LUEGO
    private fun guardarUsuarioOffline(nombre: String, correo: String, contrasena: String) {

        // 1. Guardar en cola JSON para Google Sheets
        OfflineQueueManager.agregarRegistroUsuario(this, nombre, correo, contrasena)

        // 2. Guardar también en Base de Datos Room
        val usuario = Usuario(
            nombre = nombre,
            correo = correo,
            contrasena = contrasena,
            synced = false
        )

        CoroutineScope(Dispatchers.IO).launch {
            SyncRepository(this@RegistroActivity).saveUsuarioLocal(usuario)

            // 3. Encolar sincronización automática con WorkManager
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = OneTimeWorkRequestBuilder<com.example.rdekids.worker.SyncWorker>()
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(this@RegistroActivity)
                .enqueueUniqueWork("sync_usuarios", ExistingWorkPolicy.KEEP, request)
        }
    }
}


