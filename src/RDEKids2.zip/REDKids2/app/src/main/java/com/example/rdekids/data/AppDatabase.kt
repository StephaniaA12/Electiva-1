package com.example.rdekids.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.rdekids.data.room.dao.PuntajeDao
import com.example.rdekids.data.room.entities.Puntaje
import com.example.rdekids.data.tareas.Tarea
import com.example.rdekids.data.tareas.TareaDao


@Database(
    entities = [User::class, Tarea::class, Puntaje::class], // Añade Puntaje a la lista de entidades
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun tareaDao(): TareaDao
    abstract fun puntajeDao(): PuntajeDao  // Asegúrate de tener este DAO para Puntaje

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "rdekids_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}