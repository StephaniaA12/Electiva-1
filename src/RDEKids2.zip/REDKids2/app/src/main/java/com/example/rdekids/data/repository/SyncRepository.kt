package com.example.rdekids.data.repository

import android.content.Context
import com.example.rdekids.data.GoogleSheetsService
import com.example.rdekids.data.room.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import com.example.rdekids.data.room.entities.Usuario


class SyncRepository(context: Context) {

    private val db = AppDatabase.getDatabase(context)

    suspend fun saveUsuarioLocal(usuario: Usuario) = withContext(Dispatchers.IO) {
        db.usuarioDao().insert(usuario)  // Guarda el usuario en la base de datos de Room
    }

    suspend fun sincronizarTodo() = withContext(Dispatchers.IO) {

        //Usuarios
        val usuariosPend = db.usuarioDao().getPendientes()
        for (u in usuariosPend) {
            val json = JSONObject().apply {
                put("action", "registrarUsuario")
                put("nombre", u.nombre)
                put("correo", u.correo)
                put("contrasena", u.contrasena)
            }

            if (GoogleSheetsService.enviarPostSimple(json)) {
                db.usuarioDao().marcarSincronizado(u.id)
            }
        }

        //Puntajes
        val puntajesPend = db.puntajeDao().getPendientes()
        for (p in puntajesPend) {
            val json = JSONObject().apply {
                put("action", "enviarPuntaje")
                put("usuario", p.usuario)
                put("puntaje", p.puntaje)
            }

            if (GoogleSheetsService.enviarPostSimple(json)) {
                db.puntajeDao().marcarSincronizado(p.id)
            }
        }
    }
}

