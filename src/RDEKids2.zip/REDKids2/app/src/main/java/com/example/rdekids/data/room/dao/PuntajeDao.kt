package com.example.rdekids.data.room.dao

import androidx.room.*
import com.example.rdekids.data.room.entities.Puntaje

@Dao
interface PuntajeDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(p: Puntaje): Long

    @Query("SELECT * FROM puntaje WHERE synced = 0")
    suspend fun getPendientes(): List<Puntaje>

    @Query("UPDATE puntaje SET synced = 1 WHERE id = :id")
    suspend fun marcarSincronizado(id: Long)
}


