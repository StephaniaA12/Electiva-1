package com.example.rdekids.data.room.dao

import androidx.room.*
import com.example.rdekids.data.room.entities.Usuario


@Dao
interface UsuarioDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(usuario: Usuario): Long

    @Query("SELECT * FROM usuario WHERE synced = 0")
    suspend fun getPendientes(): List<Usuario>

    @Query("UPDATE usuario SET synced = 1 WHERE id = :id")
    suspend fun marcarSincronizado(id: Long)
}

