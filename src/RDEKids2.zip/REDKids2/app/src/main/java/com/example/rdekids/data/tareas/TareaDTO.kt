package com.example.rdekids.data.tareas

data class TareaDTO(
    val id: Int,
    val title: String,
    val completed: Boolean
)

