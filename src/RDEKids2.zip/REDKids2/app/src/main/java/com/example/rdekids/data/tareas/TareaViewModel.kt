package com.example.rdekids.data.tareas

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class TareaViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = TareaRepository(application)
    private val _tareas = MutableLiveData<List<Tarea>>()
    val tareas: LiveData<List<Tarea>> = _tareas

    fun sincronizar() {
        viewModelScope.launch {
            val data = repo.sincronizarTareas()
            _tareas.postValue(data)
        }
    }
}

